#include<fstream>
#include<iostream>
#include<conio.h>
using namespace std;



char user,shopkeeper1,customer1;
int total=0;

struct arr
{
    int stock_item,prod_id;
    string prod_name,company_name;
    double prod_price;
};
arr a[100];

struct orders
{
    int order_id;
    string cust_name,card_num,cvv;

};

orders o[100];

class shop_inventory
{


public:
    void user_choice();
    void continue_choice();
    void shopkeeper();
    void customer();
    void add_prod();
    void remove_prod();
    void display_prod();
    void search_prod();
    void update_prod();
    void buy_prod();

};

void shop_inventory::add_prod()
{

    int choice,count_id=1;
    cout<<"How many product you want to insert? \n";
    cin>>choice;


    for(int i=total; i<total+choice; i++)
    {
        a[i].prod_id = count_id;

        cout<<"Product Id: "<<a[i].prod_id;
        cout<<"\nEnter Product name: ";
        cin>>a[i].prod_name;
        cout<<"Enter Product Price: ";
        cin>>a[i].prod_price;
        cout<<"Enter Stock item: ";
        cin>>a[i].stock_item;
        cout<<"Enter Company name: ";
        cin>>a[i].company_name;
        cout<<"\n";

        count_id++;

    }

    total = total + choice;

    cout<<"\n\n";
    continue_choice();

}
void shop_inventory::remove_prod()
{

    if(total != 0)
    {
        cout<<"1. Remove all product details\n";
        cout<<"2. Remove specific product details.\n\n";


        user=getch();

        if(user == '1')
        {
            total = 0;
            cout<<"All records deleted\n";
        }
        if(user == '2')
        {
            int id;
            cout<<"Enter the product Id which you want to delete: ";
            cin>>id;

            for(int i=0; i<total; i++)
            {
                if(a[i].prod_id == id)
                {
                    for(int j=i; j<total; j++)
                    {
                        a[j].prod_id = a[j+1].prod_id;
                        a[j].prod_name = a[j+1].prod_name;
                        a[j].prod_price = a[j+1].prod_price;
                        a[j].stock_item = a[j+1].stock_item;
                        a[j].company_name = a[j+1].company_name;
                        total--;
                        cout<<"Record deleted\n";
                        break;
                    }
                }
                if(i== total-1)
                {
                    cout<<"No such record found\n";
                }
            }
        }

    }
    else
    {
        cout<<"No Products in shop inventory\n";
    }


    cout<<"\n\n";
    continue_choice();

}




void shop_inventory::display_prod()
{

    if(total != 0)
    {
        cout<<"------------------------------------------------------------------------------------------------------------------------\n";
        cout<<" \nProduct Id \t\t product_name \t\t product_price \t\t Stock items \t\t Company name \n";
        cout<<"------------------------------------------------------------------------------------------------------------------------\n";
        for(int i=0; i<total; i++)
        {
            cout<<a[i].prod_id<<"\t\t\t"<<a[i].prod_name<<"\t\t\t"<<a[i].prod_price<<"\t\t\t"<<a[i].stock_item<<"\t\t\t"<<a[i].company_name<<"\n";

        }
    }
    else
    {
        cout<<"No Products in shop inventory";
    }
    cout<<"\n\n";
    continue_choice();

}




void shop_inventory::search_prod()
{
    if(total != 0)
    {
        int id;
        cout<<"Enter the product Id which you want to search: ";
        cin>>id;


        cout<<"------------------------------------------------------------------------------------------------------------------------\n";
        cout<<" \nProduct Id \t\t product_name \t\t product_price \t\t Stock items \t\t Company name \n";
        cout<<"------------------------------------------------------------------------------------------------------------------------\n";
        for(int i=0; i<total; i++)
        {
            if(id == a[i].prod_id)
            {
                cout<<a[i].prod_id<<"\t\t\t"<<a[i].prod_name<<"\t\t\t"<<a[i].prod_price<<"\t\t\t"<<a[i].stock_item<<"\t\t\t"<<a[i].company_name<<"\n";
                break;
            }
            if(i == total-1)
            {
                cout<<"No such record found\n";
            }
        }
    }
    else
    {
        cout<<"No Products in shop inventory\n";
    }
    cout<<"\n\n";
    continue_choice();

}



void shop_inventory::update_prod()
{

    if(total != 0)
    {
        int id;
        cout<<"Enter the product Id which you want to update: ";
        cin>>id;

        cout<<"\nPrevious Product Details\n\n";

        cout<<"------------------------------------------------------------------------------------------------------------------------\n";
        cout<<" \nProduct Id \t\t product_name \t\t product_price \t\t Stock items \t\t Company name \n";
        cout<<"------------------------------------------------------------------------------------------------------------------------\n";

        for(int i=0; i<total; i++)
        {
            if(id == a[i].prod_id)
            {

                cout<<a[i].prod_id<<"\t\t\t"<<a[i].prod_name<<"\t\t\t"<<a[i].prod_price<<"\t\t\t"<<a[i].stock_item<<"\t\t\t"<<a[i].company_name<<"\n";
                cout<<"\n\n";

                cout<<"Enter new product details\n\n ";

                cout<<"\nEnter Product name: ";
                cin>>a[i].prod_name;
                cout<<"Enter Product Price: ";
                cin>>a[i].prod_price;
                cout<<"Enter Stock item: ";
                cin>>a[i].stock_item;
                cout<<"Enter Company name: ";
                cin>>a[i].company_name;
                cout<<"\n";

                cout<<"\n Updated Product Details \n\n";
                cout<<"------------------------------------------------------------------------------------------------------------------------\n";
                cout<<" \nProduct Id \t\t product_name \t\t product_price \t\t Stock items \t\t Company name \n";
                cout<<"------------------------------------------------------------------------------------------------------------------------\n";
                cout<<a[i].prod_id<<"\t\t\t"<<a[i].prod_name<<"\t\t\t"<<a[i].prod_price<<"\t\t\t"<<a[i].stock_item<<"\t\t\t"<<a[i].company_name<<"\n";
                cout<<"\n\n";
                break;
            }
            if(i == total-1)
            {
                cout<<"No such record found\n";
            }
        }
    }
    else
    {
        cout<<"No Products in shop inventory\n";
    }
    cout<<"\n\n";

    continue_choice();



}



void shop_inventory::buy_prod()
{
    if(total != 0)
    {
        int id,num;
        cout<<"Enter the product Id which you want to Buy: ";
        cin>>id;
        cout<<"No the quantity: ";
        cin>>num;
        cout<<"\n\n";
        for(int i=0; i<total; i++)
        {
            if(id == a[i].prod_id)
            {
                cout<<"Your product details are: \n\n";
                cout<<"------------------------------------------------------------------------------------------------------------------------\n";
                cout<<" \nProduct Id \t\t product_name \t\t product_price \t\t Stock items \t\t Company name \n";
                cout<<"------------------------------------------------------------------------------------------------------------------------\n";
                cout<<a[i].prod_id<<"\t\t\t"<<a[i].prod_name<<"\t\t\t"<<a[i].prod_price<<"\t\t\t"<<a[i].stock_item<<"\t\t\t"<<a[i].company_name<<"\n";
                cout<<"\n\n\n";

                if(num <= a[i].stock_item)
                {
                    o[i].order_id= a[i].prod_id;
                    cout<<"Enter your name: ";
                    cin>>o[i].cust_name;
                    cout<<"Enter your 16 digit credit card number: ";
                    cin>>o[i].card_num;
                    while(o[i].card_num.length() != 16)
                    {
                        cout<<"Invalid, Please try again.....\n Enter your 16 digit credit card number: ";
                        cin>>o[i].card_num;
                    }
                    cout<<"Enter 3 digit CVV: ";
                    cin>>o[i].cvv;
                    while(o[i].cvv.length() != 3)
                    {
                        cout<<"Invalid, Please try again.....\n Enter your 3 digit CVV: ";
                        cin>>o[i].cvv;
                    }


                    cout<<"\n------------------------------------------------------------------------------------------------------------------------\n";
                    cout<<" Product ID \t Product name \t\t Quantity \t Customer name \t\tcredit card no \t\t CVV";
                    cout<<"\n------------------------------------------------------------------------------------------------------------------------\n";
                    cout<<o[i].order_id<< "\t\t"<< a[i].prod_name <<"\t\t\t"<< num <<"\t\t"<< o[i].cust_name<<" \t\t\t"<< o[i].card_num<<" \t"<< o[i].cvv<<"\n";

                    cout<<"\n\nConfirm your order ? y/n : ";
                    char flag;
                    flag=getch();
                    if(flag == 'y')
                    {
                        cout<<"Order confirmed !!";

                        fstream p;  //file pointer

                        p.open("orders.csv", ios::out | ios::app);   //create or open file with filename data

                        p <<o[i].order_id<<", "
                          <<a[i].prod_name<<", "
                          <<num<<", "
                          <<o[i].cust_name<<", "
                          <<o[i].card_num<<", "
                          <<o[i].cvv<<"\n";

                    }
                    else
                    {

                        cout<<"Order cancelled....try again !!";
                    }

                    a[i].stock_item = a[i].stock_item - num;
                    break;
                }
                else
                {
                    cout<<"product out of stock";
                    break;
                }

            }
            if(i==total-1)
            {
                cout<<"No such record found\n";
            }
        }
    }
    else
    {
        cout<<"No Products in shop inventory\n";
    }
    cout<<"\n\n";

    continue_choice();

}



void shop_inventory::shopkeeper()
{
    cout<<"\n\n|--------------SHOPKEEPER--------------|\n\n\n";
    cout<<"1. Add Product\n";
    cout<<"2. Remove Product\n";
    cout<<"3. Display Product\n";
    cout<<"4. Search Product\n";
    cout<<"5. Update Product\n\n";


    cout<<"Enter your choice: ";
    cout<<"\n\n";
    shopkeeper1=getch();

    switch(shopkeeper1)
    {
    case '1':
        add_prod();
        break;

    case '2':
        remove_prod();
        break;

    case '3':
        display_prod();
        break;

    case '4':
        search_prod();
        break;

    case '5':
        update_prod();
        break;

    default:
        cout<<"\n Invalid Input\n";
        user_choice();
        break;

    }
}



void shop_inventory::customer()
{

    cout<<"\n\n|----------CUSTOMER----------|\n\n\n";
    cout<<"1. Display Product\n";
    cout<<"2. Search Product\n";
    cout<<"3. Buy Product\n\n";



    cout<<"Enter your choice: ";
    cout<<"\n";
    customer1=getch();


    switch(customer1)
    {
    case '1':
        display_prod();
        break;

    case '2':
        search_prod();
        break;

    case '3':
        buy_prod();
        break;

    default:
        cout<<"\n Invalid Input\n";
        user_choice();
        break;
    }
}



void shop_inventory::user_choice()
{
    cout<<"\n\t\t\t\t\t==================================\n";
    cout<<"\t\t\t\t\t\t SHOP INVENTORY \n";
    cout<<"\t\t\t\t\t==================================\n";
    cout<<"\n\n\t\t\t\t\t\t 1. Shopkeeper";
    cout<<"\n\n\t\t\t\t\t\t 2. Customer";
    cout<<"\n\n\t__________________________________________________________________________________________________\n\n\n";

    cout<<"Enter your choice: ";
    user=getch();

    switch(user)
    {
    case '1':
        shopkeeper();
        break;

    case '2':
        customer();
        break;

    default:
        cout<<"\n Invalid input \n";
        user_choice();
        break;
    }
}



void shop_inventory::continue_choice()
{
    char ch;
    cout<<"Do you want to continue? m:main_menu / s:shopkeeper_menu / c:customer_menu =  ";
    cin>>ch;
    cout<<"\n";
    if(ch=='s')
    {
        shopkeeper();
    }
    else if(ch=='c')
    {
        customer();
    }

    else if(ch=='m')
    {
        user_choice();
    }

    else
    {
        cout<<"\n\n Invalid Input\n\n";
        user_choice();
    }
    cout<<"\n\n";

}





int main()
{
    shop_inventory si;


    cout<<"\n\n\n\n\n\n\n\n\n\n\t\t\t\t\t\t=========================================\n";
    cout<<"\t\t\t\t\t\t\tWelcome to Shop Inventory\n";
    cout<<"\t\t\t\t\t\t=========================================\n";
    getch();
    system("cls");



    si.user_choice();

    return 0;
}
